import boto3
import json
import os

comprehend = boto3.client("comprehend")
dynamodb = boto3.resource("dynamodb")

# DynamoDB table name (we will create it later)
TABLE_NAME = os.environ.get("WATCHLIST_TABLE", "MovieWatchlist")
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))

        username = body.get("username", "guest")
        movie = body.get("movie")
        review = body.get("review")
        action = body.get("action", "analyze")

        # ---- Sentiment analysis ----
        sentiment = None
        if review:
            sentiment = comprehend.detect_sentiment(Text=review, LanguageCode="en")["Sentiment"]

        # ---- Actions ----
        if action == "add" and movie:
            table.put_item(Item={
                "username": username,
                "movie": movie,
                "review": review or "",
                "sentiment": sentiment or "N/A"
            })
            response_body = {"message": f"{movie} added to watchlist."}

        elif action == "view":
            res = table.query(
                KeyConditionExpression=boto3.dynamodb.conditions.Key("username").eq(username)
            )
            watchlist = [item["movie"] for item in res.get("Items", [])]
            response_body = {"watchlist": watchlist}

        else:  # analyze only
            response_body = {
                "message": "Analysis complete",
                "sentiment": sentiment,
                "recommendations": [
                    "Inception",
                    "The Dark Knight",
                    "Interstellar"
                ] if sentiment == "POSITIVE" else [
                    "The Pursuit of Happyness",
                    "Inside Out",
                    "Good Will Hunting"
                ]
            }

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
            },
            "body": json.dumps(response_body)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
            },
            "body": json.dumps({"error": str(e)})
        }
