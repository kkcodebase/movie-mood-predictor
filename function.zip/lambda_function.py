import json
import random

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))

        username = body.get("username", "guest")
        movie = body.get("movie", "Unknown")
        review = body.get("review", "")
        action = body.get("action", "analyze")

        if action == "view":
            # Dummy watchlist (replace with DB later if needed)
            return {
                "statusCode": 200,
                "headers": {"Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "watchlist": ["Inception", "Interstellar", "The Dark Knight"]
                })
            }

        # Naive sentiment detection
        positives = ["good", "great", "awesome", "amazing", "love", "excellent"]
        negatives = ["bad", "boring", "worst", "hate", "awful", "poor"]

        sentiment = "neutral"
        review_lower = review.lower()
        if any(word in review_lower for word in positives):
            sentiment = "positive"
        elif any(word in review_lower for word in negatives):
            sentiment = "negative"

        response = {
            "username": username,
            "movie": movie,
            "sentiment": sentiment,
            "message": f"Your review of '{movie}' seems {sentiment}!"
        }

        return {
            "statusCode": 200,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps(response)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"error": str(e)})
        }
